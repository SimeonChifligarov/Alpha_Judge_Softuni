from project.knight import Knight


class DarkKnight(Knight):
    """
    This class is about a dark knight who is a kind of knight.
    """
    pass


if __name__ == '__main__':
    # dark_knight_instance = DarkKnight()
    pass
