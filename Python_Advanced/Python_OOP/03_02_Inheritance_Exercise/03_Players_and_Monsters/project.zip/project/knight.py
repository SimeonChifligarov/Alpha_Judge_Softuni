from project.hero import Hero


class Knight(Hero):
    """
    This class is about a knight who is a kind of hero.
    """
    pass


if __name__ == '__main__':
    # knight_instance = Knight(username='Lancelot', level=20)
    pass
