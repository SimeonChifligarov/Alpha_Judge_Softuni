from project.dark_wizard import DarkWizard


class SoulMaster(DarkWizard):
    """
    This class is about a soul master who is a kind of dark wizard.
    """
    pass


if __name__ == '__main__':
    # soul_master_instance = SoulMaster(username='Zane', level=12)
    pass
