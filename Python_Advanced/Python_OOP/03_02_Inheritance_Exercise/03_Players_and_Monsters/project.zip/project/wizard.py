from project.hero import Hero


class Wizard(Hero):
    """
    This class is about a wizard who is a kind of hero.
    """
    pass


if __name__ == '__main__':
    # wizard_instance = Wizard(username='Merlin', level=30)
    pass
