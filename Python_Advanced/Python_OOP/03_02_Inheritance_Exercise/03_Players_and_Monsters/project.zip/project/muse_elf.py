from project.elf import Elf


class MuseElf(Elf):
    """
    This class is about a muse elf who is a kind of elf.
    """
    pass


if __name__ == '__main__':
    # muse_elf_instance = MuseElf(username='Lira', level=8)
    pass
