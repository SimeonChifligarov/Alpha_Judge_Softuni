from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    """
    This class is about a blade knight who is a kind of dark knight.
    """
    pass


if __name__ == '__main__':
    # blade_knight_instance = BladeKnight()
    pass
