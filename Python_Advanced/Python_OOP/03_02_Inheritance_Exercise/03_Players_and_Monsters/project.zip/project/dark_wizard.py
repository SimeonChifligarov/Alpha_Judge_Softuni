from project.wizard import Wizard


class DarkWizard(Wizard):
    """
    This class is about a dark wizard who is a kind of wizard.
    """
    pass


if __name__ == '__main__':
    # dark_wizard_instance = DarkWizard()
    pass
