from project.hero import Hero


class Elf(Hero):
    """
    This class is about an elf who is a kind of hero.
    """
    pass


if __name__ == '__main__':
    # elf_instance = Elf()
    pass
