class Vehicle:
    """
    This class is about a vehicle that can move.

    Methods:
        move(): Says that the vehicle is moving.
    """

    def move(self) -> str:
        return 'moving...'


if __name__ == '__main__':
    # vehicle_instance = Vehicle()
    # print(vehicle_instance.move())
    pass
