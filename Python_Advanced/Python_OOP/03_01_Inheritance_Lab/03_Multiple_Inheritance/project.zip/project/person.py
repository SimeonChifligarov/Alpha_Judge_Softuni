class Person:
    """
    This class is about a person that can sleep.

    Methods:
        sleep(): Says that the person is sleeping.
    """

    def sleep(self) -> str:
        return 'sleeping...'


if __name__ == '__main__':
    # person_instance = Person()
    # print(person_instance.sleep())
    pass
