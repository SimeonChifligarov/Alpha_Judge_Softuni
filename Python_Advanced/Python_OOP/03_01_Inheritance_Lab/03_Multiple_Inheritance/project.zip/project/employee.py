class Employee:
    """
    This class is about an employee that can get fired.

    Methods:
        get_fired(): Says that the employee is fired.
    """

    def get_fired(self) -> str:
        return 'fired...'


if __name__ == '__main__':
    # employee_instance = Employee()
    # print(employee_instance.get_fired())
    pass
