from project.customer import Customer
from project.dvd import DVD


class MovieWorld:
    DVD_CAPACITY = 15
    CUSTOMER_CAPACITY = 10

    def __init__(self, name):
        self.name = name
        self.customers = []
        self.dvds = []

    @staticmethod
    def dvd_capacity():
        return 15

    @staticmethod
    def customer_capacity():
        return 10

    def add_customer(self, customer: Customer):
        if self.CUSTOMER_CAPACITY <= len(self.customers):
            return

        self.customers.append(customer)

    def add_dvd(self, dvd: DVD):
        if self.DVD_CAPACITY <= len(self.dvds):
            return

        self.dvds.append(dvd)

    def rent_dvd(self, customer_id: int, dvd_id: int):
        current_customer = [c for c in self.customers if c.id == customer_id][0]
        current_dvd = [d for d in self.dvds if d.id == dvd_id][0]

        if current_dvd in current_customer.rented_dvds:
            return f'{current_customer.name} has already rented {current_dvd.name}'

        if current_dvd.is_rented:
            return 'DVD is already rented'

        if current_customer.age < current_dvd.age_restriction:
            return f'{current_customer.name} should be at least {current_dvd.age_restriction} to rent this movie'

        current_customer.rented_dvds.append(current_dvd)
        current_dvd.is_rented = True
        return f'{current_customer.name} has successfully rented {current_dvd.name}'

    def return_dvd(self, customer_id, dvd_id):
        current_customer = [c for c in self.customers if c.id == customer_id][0]
        current_dvd = [d for d in self.dvds if d.id == dvd_id][0]

        if current_dvd not in current_customer.rented_dvds:
            return f'{current_customer.name} does not have that DVD'

        current_customer.rented_dvds.remove(current_dvd)
        current_dvd.is_rented = False
        return f'{current_customer.name} has successfully returned {current_dvd.name}'

    def __repr__(self):
        repr_result = []
        for customer in self.customers:
            repr_result.append(repr(customer))

        for dvd in self.dvds:
            repr_result.append(repr(dvd))

        return '\n'.join(repr_result)
